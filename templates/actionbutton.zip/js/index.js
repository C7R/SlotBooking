document.addEventListener("DOMContentLoaded", function() {
  var headerText = document.getElementById('header-text'),
      dropdown = document.getElementById('dropdown'),
      items = dropdown.children,
      f0 = document.getElementById('arrow-down'),
      f1 = document.getElementById('close'),
      tl = new TimelineMax({paused: true, reversed: true});

  tl
    .to(headerText, 0.3, {autoAlpha: 0, ease: Power4.easeOut})
    .to(f0, 0.15, {morphSVG: f1, ease:Power1.easeOut}, "-=0.15")
    .to(dropdown, 0.2, {scaleY: 1, autoAlpha: 1, visibility: "visible", ease: Power3.easeOut}, "-=0.2")
    .staggerFrom(items, 0.25, {y: -10, autoAlpha: 0, ease: Power3.easeOut}, 0.1);

  header.addEventListener('click', function() {
    tl.reversed() ? tl.play() : tl.reverse();
  })
});